Lightbox letter generator output

Files in this archive:
  NN_<letter>_back.svg    — solid letter outline (the floor)
  NN_<letter>_wall.svg    — wall ring (donut). Stack copies to (totalDepth - rabbetDepth - backThickness).
  NN_<letter>_rabbet.svg  — rabbet ring (the visible lip)
  NN_<letter>_plexi.svg   — plexi cut shape (drops into the rabbet)

Stack order from back to front:
  1× back
  N× wall  (until you reach totalDepth - rabbetDepth - backThickness)
  1× rabbet
  Plexi sheet sits inside rabbet, flush with front face.

NN preserves source word order. Spaces are skipped.
